﻿Console.WriteLine("Ingrese el radio del cilindro: ");
double radio = double.Parse(Console.ReadLine());
Console.WriteLine("Ingrese la altura del cilindro: ");
double altura = double.Parse(Console.ReadLine());
Cilindro cilindro = new Cilindro(radio, altura);
cilindro.Volumen();

public class Cilindro
{
    public double radio;
    public double altura;
    const double pi = 3.14159;

    public Cilindro(double radio, double altura)
    {
        this.radio = radio;
        this.altura = altura;
    }

    public void Volumen()
    {
        double volumen = pi * radio * radio * altura;
        Console.WriteLine($"El volumen del cilindro es: {volumen}" + " unidades cúbicas");
    }

}
