﻿int ctdEstacionamientosPiso = 0;
int ctdEstacionamientosAlPublico = 0;
int ctdEstacionamientosMoto = 0;
int ctdEstacionamientosSUV = 0;
int o = 0;

Console.WriteLine("Bienvenido al sistema de estacionamiento\n");
Console.WriteLine("Ingrese la cantidad de espacios de estacionamiento por piso: ");
ctdEstacionamientosPiso = int.Parse(Console.ReadLine());
Console.WriteLine("Ingrese la cantidad de espacios de estacionamiento al publico: ");
ctdEstacionamientosAlPublico = int.Parse(Console.ReadLine());  
Console.WriteLine("Ingrese la cantidad de espacios de estacionamiento para motos: ");
ctdEstacionamientosMoto = int.Parse(Console.ReadLine());
Console.WriteLine("Ingrese la cantidad de espacios de estacionamiento para SUV: ");
ctdEstacionamientosSUV = int.Parse(Console.ReadLine());

int ctdEstacionamientosGeneral = (ctdEstacionamientosPiso * ctdEstacionamientosAlPublico) - (ctdEstacionamientosMoto + ctdEstacionamientosSUV);
Console.WriteLine("La cantidad de espacios de estacionamiento sedan es: " + ctdEstacionamientosGeneral + "\n");

Parqueo parqueo = new Parqueo(ctdEstacionamientosPiso, ctdEstacionamientosAlPublico);

do
{
    Console.WriteLine("Por favor, seleccione una opcion: \n");
    Console.WriteLine("1. Ingresar vehiculo \n2. Ingresar lote de vehiculos \n3. Encontrar un vehiculo \n4. Retirar un vehiculo \n5. Salir \n");
    o = int.Parse(Console.ReadLine());

    switch(o)
    {
        case 1:
            Console.WriteLine("Opcion 1 seleccionada: Ingresar vehiculo \n");
            Vehiculo vehiculo = new Vehiculo();
            vehiculo.RegistrarVehiculo();

            bool asignado = parqueo.AsignarPrimerEspacioLibre(vehiculo);

            if (asignado)
                Console.WriteLine("\nEl vehiculo ha sido registrado y asignado con éxito! \n");
            else
                Console.WriteLine("\nNo hay espacio disponible para el vehiculo. \n");

            parqueo.MostrarEstado();
        break;

        case 2:
            Console.WriteLine("Opcion 2 seleccionada: Ingresar lote de vehiculos \n");
            string[] marcas = { "Honda", "Mazda", "Hyundai", "Toyota", "Suzuki" };
            string[] colores = { "Rojo", "Azul", "Negro", "Gris", "Blanco" };
            string[] tipos = { "Moto", "Sedan", "SUV" };
        
            Random rnd = new Random();
            int cantidadVehiculos = rnd.Next(2, 7);
            Console.WriteLine($"Se generarán {cantidadVehiculos} vehículos.\n");

            for (int i = 0; i < cantidadVehiculos; i++)
            {
                Vehiculo v = new Vehiculo();
                v.marcaVehiculo = marcas[rnd.Next(marcas.Length)];
                v.colorVehiculo = colores[rnd.Next(colores.Length)];
                v.tipoVehiculo = tipos[rnd.Next(tipos.Length)];

                // Generar placa válida (3 letras + 3 números)
                string placa = "";
                for (int j = 0; j < 3; j++)
                    placa += (char)rnd.Next('A', 'Z' + 1);
                for (int j = 0; j < 3; j++)
                    placa += rnd.Next(0, 10).ToString();

                v.placaVehiculo = placa;
                v.horaEntrada = rnd.Next(6, 21);

                bool espacioAsignado = parqueo.AsignarPrimerEspacioLibre(v);
                if (espacioAsignado)
                    Console.WriteLine($"Vehículo {i + 1}: Marca={v.marcaVehiculo}, Color={v.colorVehiculo}, Tipo={v.tipoVehiculo}, Placa={v.placaVehiculo}, HoraEntrada={v.horaEntrada}");
                else
                {
                    Console.WriteLine("No hay espacio disponible para más vehículos.");
                    break;
                }
            }

            Console.WriteLine("\nEstado final del parqueo:\n");
            parqueo.MostrarEstado();
        break;

        case 3:
            Console.WriteLine("Opcion 3 seleccionada: Encontrar un vehiculo \n");
            Console.WriteLine("Ingrese la placa del vehículo a buscar: ");
            string placaBuscada = Console.ReadLine().ToUpper();

            bool encontrado = false;
            for (int i = 0; i < parqueo.matrizVehiculos.GetLength(0); i++)
            {
                for (int j = 0; j < parqueo.matrizVehiculos.GetLength(1); j++)
                {
                    if (parqueo.matrizVehiculos[i, j] != null && parqueo.matrizVehiculos[i, j].placaVehiculo == placaBuscada)
                    {
                        Console.WriteLine($"Vehículo encontrado en el espacio: {(char)(i + 'A')}{j + 1}");
                        encontrado = true;
                        break;
                    }
                }
                if (encontrado) break;
            }
            if (!encontrado)
                Console.WriteLine("Vehículo no encontrado.");
        break;

        case 4:
            Console.WriteLine("Opcion 4 seleccionada: Retirar un vehiculo \n");
            parqueo.RetirarVehiculo();
        break;

        case 5:
            Console.WriteLine("Saliendo del sistema... \n");
        break;
    }
} while (o != 5);


public class Parqueo
{
    public Vehiculo[,] matrizVehiculos;

    public Parqueo(int filas, int columnas)
    {
        matrizVehiculos = new Vehiculo[filas, columnas];
    }

    public void MostrarEstado()
    {
        for (int i = 0; i < matrizVehiculos.GetLength(0); i++)
        {
            for (int j = 0; j < matrizVehiculos.GetLength(1); j++)
            {
                if (matrizVehiculos[i, j] == null)
                    Console.Write($"{(char)(i + 'A')}{j + 1} ");
                else
                    Console.Write("X ");
            }
            Console.WriteLine();
        }
    }

    public bool AsignarPrimerEspacioLibre(Vehiculo vehiculo)
    {
        for (int i = 0; i < matrizVehiculos.GetLength(0); i++)
        {
            for (int j = 0; j < matrizVehiculos.GetLength(1); j++)
            {
                if (matrizVehiculos[i, j] == null)
                {
                    matrizVehiculos[i, j] = vehiculo;
                    return true;
                }
            }
        }
        return false;
    }

    public void RetirarVehiculo()
    {
        Console.WriteLine("Ingrese el código del espacio donde está su vehículo (ejemplo A1):");
        string codigoEspacio = Console.ReadLine().ToUpper();

        int fila = codigoEspacio[0] - 'A';
        int columna = int.Parse(codigoEspacio.Substring(1)) - 1;

        if (fila < 0 || fila >= matrizVehiculos.GetLength(0) || columna < 0 || columna >= matrizVehiculos.GetLength(1))
        {
            Console.WriteLine("Código de estacionamiento inválido.");
            return;
        }

        var vehiculo = matrizVehiculos[fila, columna];

        if (vehiculo == null)
        {
            Console.WriteLine("El espacio está libre, no hay vehículo registrado.");
            return;
        }

        int horasEstadia = 24 - vehiculo.horaEntrada;
        if (horasEstadia < 0) horasEstadia = 0;

        int monto = 0;
        if (horasEstadia <= 1) monto = 0;
        else if (horasEstadia <= 4) monto = 15;
        else if (horasEstadia <= 7) monto = 45;
        else if (horasEstadia <= 12) monto = 60;
        else monto = 150;

        Console.WriteLine($"Tiempo de estadía: {horasEstadia} horas.");
        Console.WriteLine($"Monto a pagar: Q{monto}");

        Console.WriteLine("Seleccione método de pago:\n1. Tarjeta/Sticker\n2. Efectivo");
        int metodoPago = int.Parse(Console.ReadLine());

        if (metodoPago == 1)
        {
            Console.WriteLine("Pago con tarjeta/sticker aceptado. Gracias.");
        }
        else if (metodoPago == 2)
        {
            Console.WriteLine("Ingrese monto entregado en efectivo:");
            int efectivo = int.Parse(Console.ReadLine());
            if (efectivo < monto)
            {
                Console.WriteLine("Monto insuficiente, no se puede completar el pago.");
                return;
            }
            int vuelto = efectivo - monto;
            Console.WriteLine($"Pago recibido: Q{efectivo}. Vuelto a entregar: Q{vuelto}");

            int[] billetes = { 100, 50, 20, 10, 5 };
            Console.WriteLine("Denominaciones del vuelto:");
            foreach (int billete in billetes)
            {
                int cant = vuelto / billete;
                if (cant > 0)
                {
                    Console.WriteLine($"{cant} billete(s) de Q{billete}");
                    vuelto %= billete;
                }
            }
        }
        else
        {
            Console.WriteLine("Método de pago inválido.");
            return;
        }

        matrizVehiculos[fila, columna] = null;
        Console.WriteLine("Vehículo retirado correctamente.");

        MostrarEstado();
    }
}

public class Vehiculo
{
    public string marcaVehiculo;
    public string colorVehiculo;
    public string placaVehiculo;
    public string tipoVehiculo;
    public int horaEntrada;

    public void RegistrarVehiculo()
    {
        Console.WriteLine("\nIngrese la marca del vehiculo: ");
        marcaVehiculo = Console.ReadLine();
        Console.WriteLine("\nIngrese el color del vehiculo: ");
        colorVehiculo = Console.ReadLine();
        PlacasValidas();
        TipoDeVehiculoValido();
        HoraDeEntradaValida();
        Console.WriteLine("\nEl vehiculo ha sido registrado con exito! \n");
    }

    void HoraDeEntradaValida()
    {
        do
        {
            Console.WriteLine("\nIngrese la hora de entrada del vehiculo (6 a 20 horas): ");
            horaEntrada = int.Parse(Console.ReadLine());
        } while (horaEntrada < 6 || horaEntrada > 20);
    }

    void PlacasValidas()
    {
        do
        {
            Console.WriteLine("\nIngrese la placa del vehiculo: ");
            placaVehiculo = Console.ReadLine();

        } while (placaVehiculo.Length != 6 || !char.IsDigit(placaVehiculo[0]) || !char.IsDigit(placaVehiculo[1]) || !char.IsDigit(placaVehiculo[2]) || !char.IsUpper(placaVehiculo[3]) || !char.IsUpper(placaVehiculo[4]) || !char.IsUpper(placaVehiculo[5]));
    }

    void TipoDeVehiculoValido()
    {
        do
        {
            Console.WriteLine("\nIngrese el tipo de vehiculo (Sedan, SUV, Moto): ");
            tipoVehiculo = Console.ReadLine();

        } while (tipoVehiculo != "Sedan" && tipoVehiculo != "SUV" && tipoVehiculo != "Moto");
    }
}
