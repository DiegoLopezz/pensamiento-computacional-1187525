﻿int hora = 0;
        Console.WriteLine("Ingrese una hora del dia en formato de 24 horas");
        hora = Convert.ToInt32(Console.ReadLine());

        if (hora >= 0 && hora <= 11)
        {
            Console.WriteLine("Buenos dias");
        }
        else if (hora >= 12 && hora <= 18)
        {
            Console.WriteLine("Buenas tardes");
        }
        else if (hora >= 19 && hora <= 23)
        {
            Console.WriteLine("Buenas noches");
        }
        else
        {
            Console.WriteLine("Hora no valida");
        }

        //Diego Alessandro Lopez Higueros 1187525