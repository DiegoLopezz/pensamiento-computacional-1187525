﻿/*int edad;
Console.WriteLine("Ingresa tu edad: ");
edad = Convert.ToInt32(Console.ReadLine());

do {
    if (edad > 100 || edad < 1){
        Console.WriteLine("Edad no válida, ingresa una edad entre 1 y 100");
        Console.WriteLine("Ingresa tu edad: ");
        edad = Convert.ToInt32(Console.ReadLine());
    }
}while (edad > 100 || edad < 1);

Console.WriteLine("Tu edad es: "+ edad);*/

int num, resultado;

            Console.WriteLine("Ingresa un número: ");
            num = Convert.ToInt32(Console.ReadLine());

            do{
                if (num <= 0){
                    Console.WriteLine("Número no válido, ingresa un número mayor a 0");
                    Console.WriteLine("Ingresa un número: ");
                    num = Convert.ToInt32(Console.ReadLine());
                }
            }while (num <= 0);
        
        for(int i = 1; i <= 10; i++){
            resultado = num * i;
            Console.WriteLine(num + " x " + i + " = " + resultado);
            
        }

        //Diego Alessandro Lopez Higueros 1187525
