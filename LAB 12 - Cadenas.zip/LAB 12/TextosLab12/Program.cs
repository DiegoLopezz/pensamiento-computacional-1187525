﻿//Diego Alessandro Lopez Higueros 1187525

string input;
int contadorDePalabras = 1;

Console.WriteLine("Ingrese el texto que desee: ");
input = Console.ReadLine();

string letraMayus = input[0].ToString().ToUpper();

for (int i = 1; i < input.Length; i++)
{
    if (input[i] == ' ')
    {
        letraMayus += ' ' + input[i + 1].ToString().ToUpper();
        contadorDePalabras += 1;
        i++;
    }
    else
    {
        letraMayus += input[i].ToString().ToLower();
    }
}

Console.WriteLine("El texto ingresado es: " + input);
Console.WriteLine("El texto con la primera letra de cada palabra en mayúscula es: " + letraMayus);
Console.WriteLine("El texto tiene " + +contadorDePalabras + " palabras");


