﻿using System;

int ctdEstacionamientosPiso = 0;
int ctdEstacionamientosAlPublico = 0;
int ctdEstacionamientosMoto = 0;
int ctdEstacionamientosSUV = 0;
int o = 0;

// Bienvenida del programa y lectura de las variables de entrada

Console.WriteLine("Bienvenido al sistema de estacionamiento\n");
Console.WriteLine("Ingrese la cantidad de espacios de estacionamiento por piso: ");
ctdEstacionamientosPiso = int.Parse(Console.ReadLine());
Console.WriteLine("Ingrese la cantidad de espacios de estacionamiento al publico: ");
ctdEstacionamientosAlPublico = int.Parse(Console.ReadLine());  
Console.WriteLine("Ingrese la cantidad de espacios de estacionamiento para motos: ");
ctdEstacionamientosMoto = int.Parse(Console.ReadLine());
Console.WriteLine("Ingrese la cantidad de espacios de estacionamiento para SUV: ");
ctdEstacionamientosSUV = int.Parse(Console.ReadLine());

Parqueo parqueo = new Parqueo(ctdEstacionamientosPiso, ctdEstacionamientosAlPublico, ctdEstacionamientosMoto, ctdEstacionamientosSUV);

//do para que las acciones del programa se repitan hasta que decida salir
do
{
    Console.WriteLine("Por favor, seleccione una opcion: \n");
    Console.WriteLine("1. Ingresar vehiculo \n2. Ingresar lote de vehiculos \n3. Encontrar un vehiculo \n4. Retirar un vehiculo \n5. Salir \n");
    o = int.Parse(Console.ReadLine());

    switch (o)
    {
        case 1:
            Console.WriteLine("Opcion 1 seleccionada: Ingresar vehiculo \n");
            Vehiculo vehiculo = new Vehiculo();
            vehiculo.RegistrarVehiculo(); // Registrar el vehículo

            bool asignado = parqueo.AsignarEspacioPorTipo(vehiculo); // Asignar espacio al vehículo

            if (asignado)
                Console.WriteLine("\nEl vehiculo ha sido registrado y asignado con éxito! \n");
            else
                Console.WriteLine("\nNo hay espacio disponible para el tipo de vehiculo. \n");

            parqueo.MostrarEstado();
            break;

        case 2:
            Console.WriteLine("Opcion 2 seleccionada: Ingresar lote de vehiculos \n");
            string[] marcas = { "Honda", "Mazda", "Hyundai", "Toyota", "Suzuki" };
            string[] colores = { "Rojo", "Azul", "Negro", "Gris", "Blanco" };
            string[] tipos = { "Moto", "Sedan", "SUV" };
            
            // Arreglos propuestos para ingresar aleatoriamente

            Random rnd = new Random(); // Llamar a la clase random
            int cantidadVehiculos = rnd.Next(2, 7); // Generar un número aleatorio entre 2 y 6
            Console.WriteLine($"Se generarán {cantidadVehiculos} vehículos.\n"); // Mostrar la cantidad generada

            for (int i = 0; i < cantidadVehiculos; i++)
            {
                Vehiculo v = new Vehiculo(); // Crear un nuevo vehículo
                v.marcaVehiculo = marcas[rnd.Next(marcas.Length)];// Asignar marca aleatoria
                v.colorVehiculo = colores[rnd.Next(colores.Length)]; // Asignar color aleatorio
                v.tipoVehiculo = tipos[rnd.Next(tipos.Length)];// Asignar tipo aleatorio

                string placa = "";
                for (int j = 0; j < 3; j++)
                    placa += (char)rnd.Next('A', 'Z' + 1); // Generar letras aleatorias recorriendo el alfabeto
                for (int j = 0; j < 3; j++)
                    placa += rnd.Next(0, 10).ToString(); // Generar números aleatorios de 0 a 9 y convierte a string

                v.placaVehiculo = placa; // Asignar placa generada
                v.horaEntrada = rnd.Next(6, 21); // Generar hora de entrada aleatoria entre 6 y 20

                bool espacioAsignado = parqueo.AsignarEspacioPorTipo(v);
                if (espacioAsignado) //Verificar si se asignó el espacio
                    Console.WriteLine($"Vehículo {i + 1}: Marca={v.marcaVehiculo}, Color={v.colorVehiculo}, Tipo={v.tipoVehiculo}, Placa={v.placaVehiculo}, HoraEntrada={v.horaEntrada}");
                else
                {
                    Console.WriteLine("No hay espacio disponible para más vehículos.");
                    break;
                }
            }

            Console.WriteLine("\nEstado final del parqueo:\n");
            parqueo.MostrarEstado();
            break;

        case 3:
            Console.WriteLine("Opcion 3 seleccionada: Encontrar un vehiculo \n");
            Console.WriteLine("Ingrese la placa del vehículo a buscar: ");
            string placaBuscada = Console.ReadLine().ToUpper();

            bool encontrado = false;
            for (int i = 0; i < parqueo.matrizVehiculos.GetLength(0); i++)
            {
                for (int j = 0; j < parqueo.matrizVehiculos.GetLength(1); j++) //Itera desde 1 hasta la longitud de la matriz porque son las columnas
                {
                    if (parqueo.matrizVehiculos[i, j] != null && parqueo.matrizVehiculos[i, j].placaVehiculo == placaBuscada) //Busca donde no este vacio y que la placa sea igual que la mostrada
                    {
                        Console.WriteLine($"Vehículo encontrado en el espacio: {(char)(i + 'A')}{j + 1}"); //char(i + 'A') hace la conversión de número a letra
                        encontrado = true; // Se encontró el vehículo y cambia de falso a verdadero
                        break;
                    }
                }
                if (encontrado) break; // Si se encuentra el vehículo, se sale del bucle
            }
            if (!encontrado)
                Console.WriteLine("Vehículo no encontrado."); // Si no se encontró el vehículo, se imprime el mensaje
            break;

        case 4:
            Console.WriteLine("Opcion 4 seleccionada: Retirar un vehiculo \n");
            parqueo.RetirarVehiculo(); //Llamada al método para retirar el vehículo
            break;

        case 5:
            Console.WriteLine("Saliendo del sistema... \n");
            break;
    }
} while (o != 5); //Condicion de salida, si el usuario lo desea


public class Parqueo
{
    public Vehiculo[,] matrizVehiculos; // Matriz de vehículos

    public Parqueo(int filas, int columnas, int ctdMotos, int ctdSUV) // Constructor 
    {
        matrizVehiculos = new Vehiculo[filas, columnas]; // Inicializa la matriz de vehículos

        int total = filas * columnas;
        int ocupados = 0;

        for (int i = 0; i < filas && ocupados < ctdMotos; i++)
        {
            for (int j = 0; j < columnas && ocupados < ctdMotos; j++)
            {
                Vehiculo moto = new Vehiculo { tipoVehiculo = "Moto", placaVehiculo = "MOTOXX" }; // Asigna un espacio para la moto
                matrizVehiculos[i, j] = moto; // Asigna el vehículo a la matriz
                ocupados++; // Incrementa el contador de ocupados
            }
        }

        int usados = ocupados; // Guarda el número de espacios ocupados
        for (int i = 0; i < filas && ocupados < usados + ctdSUV; i++) 
        {
            for (int j = 0; j < columnas && ocupados < usados + ctdSUV; j++)
            {
                if (matrizVehiculos[i, j] == null)
                {
                    Vehiculo suv = new Vehiculo { tipoVehiculo = "SUV", placaVehiculo = "SUVXXX" };
                    matrizVehiculos[i, j] = suv;
                    ocupados++;
                }
            }
        }
    }

    public void MostrarEstado()
    {
        for (int i = 0; i < matrizVehiculos.GetLength(0); i++)
        {
            for (int j = 0; j < matrizVehiculos.GetLength(1); j++)
            {
                if (matrizVehiculos[i, j] == null)
                    Console.Write($"{(char)(i + 'A')}{j + 1} ");
                else if (matrizVehiculos[i, j].placaVehiculo == "MOTOXX")
                    Console.Write("M ");
                else if (matrizVehiculos[i, j].placaVehiculo == "SUVXXX")
                    Console.Write("S ");
                else
                    Console.Write("X ");

                    //Muestra el estado del mapa de los estacionamientos, si el espacio está vacío se imprime la letra y el número del espacio, si es una moto se imprime M, si es un SUV se imprime S y si es un vehículo normal se imprime X
            }
            Console.WriteLine();
        }
    }

    public bool AsignarEspacioPorTipo(Vehiculo vehiculo)
    {
        for (int i = 0; i < matrizVehiculos.GetLength(0); i++)
        {
            for (int j = 0; j < matrizVehiculos.GetLength(1); j++)
            {
                var actual = matrizVehiculos[i, j]; // Obtiene el vehículo actual en la posición (i, j)
                //var es una palabra reservada de C# que declara una variable a conveniencia (de cualquier tipo) y se le asigna el valor de la matrizVehiculos en la posición (i,j)
                if (actual != null && ((actual.placaVehiculo == "MOTOXX" && vehiculo.tipoVehiculo == "Moto") || (actual.placaVehiculo == "SUVXXX" && vehiculo.tipoVehiculo == "SUV")))
                {
                    //Busca donde no este vacio y que coincidan los parametros
                    matrizVehiculos[i, j] = vehiculo;
                    return true;
                }
                if (actual == null && vehiculo.tipoVehiculo == "Sedan")
                {
                    matrizVehiculos[i, j] = vehiculo;
                    return true;
                }
            }
        }
        return false;
    }

    public void RetirarVehiculo()
    {
        Console.WriteLine("Ingrese el código del espacio donde está su vehículo (ejemplo A1):");
        string codigoEspacio = Console.ReadLine().ToUpper();

        int fila = codigoEspacio[0] - 'A'; // Convierte la letra a número (A=0, B=1, C=2, para buscar en la matriz y su indice, fuera de como lo presenta al usuario
        int columna = int.Parse(codigoEspacio.Substring(1)) - 1; // Convierte la letra a número y resta 1 para obtener el índice

        if (fila < 0 || fila >= matrizVehiculos.GetLength(0) || columna < 0 || columna >= matrizVehiculos.GetLength(1)) //Condiciones para un correcto ingreso de la informacion
        {
            Console.WriteLine("Código de estacionamiento inválido.");
            return;
        }

        var vehiculo = matrizVehiculos[fila, columna]; // Obtiene el vehículo en la posición (fila, columna)

        if (vehiculo == null || vehiculo.placaVehiculo == "MOTOXX" || vehiculo.placaVehiculo == "SUVXXX") // Verifica si el espacio está vacío o es reservado
        {
            Console.WriteLine("El espacio está libre o es reservado, no hay vehículo registrado.");
            return;
        }

        int horasEstadia = 24 - vehiculo.horaEntrada; // Calcula las horas de estadía
        if (horasEstadia < 0) horasEstadia = 0; // Asegura que no sea negativo

        int monto = 0;
        if (horasEstadia <= 1)
            monto = 0; // 0 por cortesía
        else if (horasEstadia <= 4)
            monto = 15;
        else if (horasEstadia <= 7)
            monto = 45;
        else if (horasEstadia <= 12)
            monto = 60;
        else
            monto = 150;

        Console.WriteLine($"Tiempo de estadía: {horasEstadia} horas.");
        Console.WriteLine($"Monto a pagar: Q{monto}");

        Console.WriteLine("Seleccione método de pago:\n1. Tarjeta/Sticker\n2. Efectivo");
        int metodoPago = int.Parse(Console.ReadLine());

        if (metodoPago == 1)
        {
            Console.WriteLine("Pago con tarjeta/sticker aceptado. Gracias."); //El pago con tarjeta se procesará automáticamente y no hay añadidos
        }
        else if (metodoPago == 2)
        {
            Console.WriteLine("Ingrese monto entregado en efectivo:");
            int efectivo = int.Parse(Console.ReadLine());
            if (efectivo < monto)
            {
                Console.WriteLine("Monto insuficiente, no se puede completar el pago."); //Asegura que se ingrese un monto adecuado
                return;
            }
            int vuelto = efectivo - monto; // Calcula el vuelto
            Console.WriteLine($"Pago recibido: Q{efectivo}. Vuelto a entregar: Q{vuelto}");

            int[] billetes = { 100, 50, 20, 10, 5 };
            Console.WriteLine("Denominaciones del vuelto:");
            foreach (int billete in billetes) // Itera sobre las denominaciones de los billetes
            {
                int cant = vuelto / billete;
                if (cant > 0)
                {
                    Console.WriteLine($"{cant} billete(s) de Q{billete}");
                    vuelto %= billete;
                }
            }
            /* cant se obtiene de vuelto / billete lo que resulta en la cantidad de cada billete por denominacion
            que se puede entregar, si cant es mayor que 0 se imprimen los billetes para cada denominacion y % para el residuo y continuar con el vuelto*/
        }
        else
        {
            Console.WriteLine("Método de pago inválido.");
            return;
        }

        matrizVehiculos[fila, columna] = null; // Libera el espacio de estacionamiento
        Console.WriteLine("Vehículo retirado correctamente.");

        MostrarEstado();
    }
}

public class Vehiculo
{
    public string marcaVehiculo;
    public string colorVehiculo;
    public string placaVehiculo;
    public string tipoVehiculo;
    public int horaEntrada;

    // Atributos de la clase vehiculo, que se llenan al momento de registrar el vehiculo
    public void RegistrarVehiculo()
    {
        Console.WriteLine("\nIngrese la marca del vehiculo: ");
        marcaVehiculo = Console.ReadLine();
        Console.WriteLine("\nIngrese el color del vehiculo: ");
        colorVehiculo = Console.ReadLine();
        PlacasValidas();
        TipoDeVehiculoValido();
        HoraDeEntradaValida();
        Console.WriteLine("\nEl vehiculo ha sido registrado con exito! \n");

        // Se asegura que la placa, tipo de vehiculo y hora de entrada sean validos y se completa el registro6]
    }

    void HoraDeEntradaValida()
    {
        do
        {
            Console.WriteLine("\nIngrese la hora de entrada del vehiculo (6 a 20 horas): ");
            horaEntrada = int.Parse(Console.ReadLine());
        } while (horaEntrada < 6 || horaEntrada > 20);
        
        // Se asegura que la hora de entrada sea valida dentro de los parametros 6 a 20
    }

    void PlacasValidas()
    {
        do
        {
            Console.WriteLine("\nIngrese la placa del vehiculo: ");
            placaVehiculo = Console.ReadLine();

        } while (placaVehiculo.Length != 6 || !char.IsDigit(placaVehiculo[0]) || !char.IsDigit(placaVehiculo[1]) || !char.IsDigit(placaVehiculo[2]) || !char.IsUpper(placaVehiculo[3]) || !char.IsUpper(placaVehiculo[4]) || !char.IsUpper(placaVehiculo[5]));

        //Busca dentro de las cadenas de caracteres las condiciones para asegurarse que la placa sea válida, al igual que su longitud
    }

    void TipoDeVehiculoValido()
    {
        do
        {
            Console.WriteLine("\nIngrese el tipo de vehiculo (Sedan, SUV, Moto): ");
            tipoVehiculo = Console.ReadLine();

        } while (tipoVehiculo != "Sedan" && tipoVehiculo != "SUV" && tipoVehiculo != "Moto");

        //Asegura que el tipo de vehiculo sea uno de los tres tipos válidos
    }
}

