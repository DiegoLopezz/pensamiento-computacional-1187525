﻿double fahreheit (double temp)
{
    return (temp - 32) * 5 / 9;
}

double celsius (double temp)
{
    return (temp * 9 / 5) + 32;
}

void datosProgramador (string nombre, int edad, string carrera)
{
    Console.WriteLine("Los datos del programador son: " + "\nNombre: " + nombre + "\nEdad: " + edad + "\nCarrera: " + carrera);
}

int opcion = 0;

Console.WriteLine("Las opciones son: " 
+ "\n1. Datos del programador" 
+ "\n2. Convertir de Celsius a fahrenheit" 
+ "\n3. Convertir de fahrenheit a Celsius" 
+ "\n4. Salir");

Console.WriteLine("Ingrese la opción deseada: ");
opcion = int.Parse(Console.ReadLine()!);

switch(opcion)
{
    case 1:
        string nombre = "Diego Lopez";
        int edad = 18;
        string carrera = "Ingenieria en Sistemas";
        datosProgramador(nombre, edad, carrera);
        break;

    case 2:
        Console.WriteLine("Ingrese la temperatura en Celsius: ");
        int tempC = int.Parse(Console.ReadLine()!);
        Console.WriteLine("La temperatura en Fahrenheit es: " + celsius(tempC));
        break;

    case 3:
        Console.WriteLine("Ingrese la temperatura en Fahrenheit: ");
        int tempF = int.Parse(Console.ReadLine()!);
        Console.WriteLine("La temperatura en Celsius es: " + fahreheit(tempF));
        break;
    case 4:
        System.Environment.Exit(0);
        break;
}

