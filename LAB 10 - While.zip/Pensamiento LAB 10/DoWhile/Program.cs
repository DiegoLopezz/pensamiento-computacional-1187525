﻿int num = 0;
Random aleatorio = new Random();
int num2 = aleatorio.Next(1, 50);

Console.WriteLine("Adivina el número entre 1 y 50");
num = Convert.ToInt32(Console.ReadLine());

while (num != num2)
{
    if (num < num2)
    {
        Console.WriteLine("El número es mayor");
        num = Convert.ToInt32(Console.ReadLine());
    }
    else
    {
        Console.WriteLine("El número es menor");
        num = Convert.ToInt32(Console.ReadLine());
    }
}

Console.WriteLine("¡Adivinaste!");
