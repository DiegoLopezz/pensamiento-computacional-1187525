string nombre;
int edad;
double altura;
char mascota;

Console.WriteLine("Bienvenido");
Console.WriteLine("Ingrese su Nombre: ");
nombre = Console.ReadLine();

Console.WriteLine("Ingrese su Estatura en metros: ");
altura = Convert.ToDouble(Console.ReadLine());

Console.WriteLine("Ingrese su Edad: ");
edad = Convert.ToInt32(Console.ReadLine());

Console.WriteLine("Ingrese la inicial de su mascota: ");
mascota = Convert.ToChar(Console.ReadLine());

Console.WriteLine("Los datos ingresados son: \nDie"+nombre +"\n" +altura+ "\n"+edad+ "\n"+mascota);