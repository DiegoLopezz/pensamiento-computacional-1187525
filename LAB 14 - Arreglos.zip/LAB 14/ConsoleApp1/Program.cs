﻿//Diego Alessandro Lopez Higueros 1187525

string [] nombres = ["Juan", "Pedro", "Luisa", "Adriana", "Sofia"];
int [] notas = [88, 75, 96, 77, 59];
double promedio = 0;

for(int i = 0; i < nombres.Length; i++)
{
    Console.WriteLine(nombres[i] + " - " + notas[i]);
}

promedio = notas.Sum() / notas.Length;
Console.WriteLine("El promedio es: " + promedio);
